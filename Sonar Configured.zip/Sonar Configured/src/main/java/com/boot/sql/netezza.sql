create table IF NOT EXISTS table_name
( 
field_name1 varchar(10),
field_name2 varchar(10)
);